/* Podium L4C84L pour MyEasyOptic — script de l'extension, exécuté dans les pages MyEasyOptic.
   - Affiche un bouton « → Podium » tant qu'un devis (écran de vente) est ouvert.
   - Au clic : lit la correction (bloc Ordonnance, à défaut lignes verres) et le prix monture, ouvre Podium
     et lui transmet ces données (postMessage, directement d'onglet à onglet, sans serveur).
   - Au retour de Podium : colle le libellé exact des verres OD / OG, ouvre la loupe, présélectionne la ligne
     et coche Précalibrage au retour sur le devis. L'opticien choisit le diamètre et valide (OK). */
(() => {
  const PODIUM = 'https://lachal-groupe.github.io/Podium/';
  const ORIGIN = 'https://lachal-groupe.github.io';
  const vis = () => [...document.querySelectorAll('input')].filter(i => i.offsetParent !== null);
  const by = p => vis().filter(i => i.placeholder === p);

  /* ---------- messages à l'écran ---------- */
  const note = (msg, ok) => {
    let d = document.getElementById('podium-note');
    if (!d) {
      d = document.createElement('div'); d.id = 'podium-note';
      d.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483647;padding:12px 22px;border-radius:12px;font:600 14px/1.4 Segoe UI,Arial,sans-serif;color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.28);max-width:82vw;text-align:center';
      document.body.appendChild(d);
    }
    d.style.background = ok ? '#1d4fd7' : '#c13246'; d.textContent = msg;
    clearTimeout(d._t); d._t = setTimeout(() => d.remove(), 10000);
  };

  /* ---------- bouton « → Podium » (visible seulement sur un devis) ---------- */
  const btn = document.createElement('button');
  btn.id = 'podium-btn'; btn.type = 'button'; btn.title = 'Ouvrir Podium avec la correction et la monture de ce devis';
  btn.innerHTML = '<span style="display:inline-flex;align-items:flex-end;gap:2px;height:16px;margin-right:8px">'
    + '<i style="width:5px;height:60%;background:#fff;opacity:.75;border-radius:2px"></i><i style="width:5px;height:100%;background:#fff;border-radius:2px"></i><i style="width:5px;height:40%;background:#fff;opacity:.55;border-radius:2px"></i></span>Podium';
  btn.style.cssText = 'position:fixed;right:18px;top:50%;transform:translateY(-50%);z-index:2147483646;display:none;align-items:center;padding:12px 18px;border:0;border-radius:999px;background:linear-gradient(100deg,#0b2a7a,#1d4fd7);color:#fff;font:800 15px Segoe UI,Arial,sans-serif;box-shadow:0 8px 24px rgba(11,42,122,.35);cursor:pointer';
  btn.onmouseenter = () => { btn.style.filter = 'brightness(1.15)'; };
  btn.onmouseleave = () => { btn.style.filter = ''; };
  btn.onclick = () => envoyer();
  document.body.appendChild(btn);
  // l'application MyEasyOptic change d'écran sans recharger la page : on vérifie régulièrement
  setInterval(() => { btn.style.display = by('PV Monture').length ? 'inline-flex' : 'none'; }, 700);

  /* ---------- aller : devis -> Podium ---------- */
  let current = null, win = null;
  function envoyer() {
    const price = by('PV Monture')[0];
    if (!price) return note("Podium : ouvrez d'abord l'écran de vente / devis du client.", false);
    const S = by('Sph.'), C = by('Cyl.'), A = by('Axe'), D = by('Add.');
    const val = (arr, k) => ((arr[k] && arr[k].value) || '').trim();
    const eye = k => ({ sph: val(S, k), cyl: val(C, k), axe: val(A, k), add: val(D, k) });
    const filled = e => Object.values(e).some(Boolean);
    // les deux premières lignes Sph. sont l'ordonnance, les deux suivantes les lignes verres
    const pick = (o, v) => (S.length >= 4 && !filled(eye(o)) ? eye(v) : eye(o));
    current = { type: 'podium-client', id: Date.now(), rx: { od: pick(0, 2), og: pick(1, 3) }, framePrice: price.value };
    win = window.open(PODIUM, 'podium-l4c84l');
    if (!win) return note('Podium : autorisez les fenêtres pop-up pour MyEasyOptic.', false);
    const id = current.id; let n = 0;
    const t = setInterval(() => {   // renvoie jusqu'à ce que Podium soit prêt (connexion comprise), 2 minutes max
      if (!current || current.id !== id || current.ack || ++n > 240 || win.closed) return clearInterval(t);
      win.postMessage(current, ORIGIN);
    }, 500);
    note('Podium ouvert avec la correction et la monture de ce devis.', true);
  }

  /* ---------- retour : Podium -> devis ---------- */
  window.addEventListener('message', e => {
    if (e.origin !== ORIGIN || !e.data) return;
    if (e.data.type === 'podium-ack' && current && e.data.id === current.id) current.ack = true;
    if (e.data.type === 'podium-verres') coller(e.data);
  });

  // boutons MyEasyOptic (GWT) : ils réagissent à l'appui souris (mousedown / mouseup), pas au simple clic
  const press = el => {
    const r = el.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: window, clientX: r.left + 5, clientY: r.top + 5, button: 0 };
    ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(t => el.dispatchEvent(new MouseEvent(t, o)));
  };

  function coller(d) {
    const od = by('Libellé Verre Œil Droit')[0], og = by('Libellé Verre Œil Gauche')[0];
    if (!od || !og) return note("Podium : revenez sur l'écran du devis pour recevoir les verres.", false);
    const set = (el, v) => {
      el.focus(); el.value = v;
      ['input', 'keyup', 'change'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
      el.blur();
    };
    set(od, d.od); set(og, d.og);
    // Précalibrage : la case n'est active qu'une fois le verre sélectionné ; on la coche au retour sur le devis (3 min max)
    if (d.precal) {
      let k = 0;
      const p = setInterval(() => {
        const lab = [...document.querySelectorAll('label')].find(l => l.textContent.trim() === 'Précalibrage' && l.offsetParent);
        const cb = lab && document.getElementById(lab.htmlFor);
        if (cb && !cb.disabled) { if (!cb.checked) cb.click(); note('Précalibrage coché.', true); clearInterval(p); }
        if (++k > 360) clearInterval(p);
      }, 500);
    }
    window.focus();
    od.scrollIntoView({ block: 'center' });
    setTimeout(() => {
      const r = od.getBoundingClientRect();
      const img = document.elementFromPoint(r.left - 14, r.top + r.height / 2);
      const loupe = img && img.closest('[role=button]');
      if (!loupe) return note('Verres Podium collés : cliquez sur la loupe pour les sélectionner.', true);
      press(loupe);
      // Sélection Verre : présélection de la ligne exacte (même libellé que dans Podium)
      let k = 0;
      const t = setInterval(() => {
        const cell = [...document.querySelectorAll('div, td')].find(e => e.offsetParent && e.childElementCount === 0 && e.textContent.trim() === d.od && e.getBoundingClientRect().top > 180);
        if (cell) press(cell);
        if (cell || ++k > 20) {
          clearInterval(t);
          const precal = d.precal ? ' Le Précalibrage sera coché au retour sur le devis.' : '';
          note(d.od === d.og
            ? (cell ? 'Verre présélectionné : choisissez le diamètre puis OK.' : 'Cliquez sur la ligne exacte, choisissez le diamètre puis OK.') + precal
            : 'OD et OG sont différents : sélectionnez chaque œil, choisissez le diamètre puis OK.' + precal, true);
        }
      }, 300);
    }, 250);
  }
})();
