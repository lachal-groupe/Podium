/* Podium L4C84L pour MyEasyOptic — script de l'extension, exécuté dans les pages MyEasyOptic.
   - Affiche un bouton « → Podium » tant qu'un devis (écran de vente) est ouvert.
   - Au clic : lit la correction (bloc Ordonnance, à défaut lignes verres) et le prix monture, ouvre Podium
     et lui transmet ces données (postMessage, directement d'onglet à onglet, sans serveur).
   - Au retour de Podium, sans clic de l'opticien dans la recherche verre : colle le libellé OD / OG, ouvre la loupe,
     recherche le verre par son code EDI, sélectionne la ligne, choisit le diamètre (65/70 ou le plus proche),
     coche les suppléments (Précal, couleur Transitions, Prisme standard sur l'œil concerné) et valide.
     L'opticien contrôle ensuite le devis. */
(() => {
  const PODIUM = 'https://lachal-groupe.github.io/Podium/';
  const ORIGIN = 'https://lachal-groupe.github.io';
  const vis = () => [...document.querySelectorAll('input')].filter(i => i.offsetParent !== null);
  const by = p => vis().filter(i => i.placeholder === p);

  /* ---------- messages à l'écran ---------- */
  const note = (msg, ok, ms = 10000) => {
    let d = document.getElementById('podium-note');
    if (!d) {
      d = document.createElement('div'); d.id = 'podium-note';
      d.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483647;padding:12px 22px;border-radius:12px;font:600 14px/1.4 Segoe UI,Arial,sans-serif;color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.28);max-width:82vw;text-align:center';
      document.body.appendChild(d);
    }
    d.style.background = ok ? '#1d4fd7' : '#c13246'; d.textContent = msg;
    clearTimeout(d._t); d._t = setTimeout(() => d.remove(), ms);
  };

  /* ---------- bouton « → Podium » (visible seulement sur un devis) ---------- */
  const btn = document.createElement('button');
  btn.id = 'podium-btn'; btn.type = 'button'; btn.title = 'Ouvrir Podium avec la correction et la monture de ce devis';
  btn.innerHTML = '<span style="display:inline-flex;align-items:flex-end;gap:2px;height:16px;margin-right:8px">'
    + '<i style="width:5px;height:60%;background:#fff;opacity:.75;border-radius:2px"></i><i style="width:5px;height:100%;background:#fff;border-radius:2px"></i><i style="width:5px;height:40%;background:#fff;opacity:.55;border-radius:2px"></i></span>Podium';
  btn.style.cssText = 'position:fixed;right:18px;top:50%;transform:translateY(-50%);z-index:2147483646;display:none;align-items:center;padding:12px 18px;border:0;border-radius:999px;background:linear-gradient(100deg,#0b2a7a,#1d4fd7);color:#fff;font:800 15px Segoe UI,Arial,sans-serif;box-shadow:0 8px 24px rgba(11,42,122,.35);cursor:pointer';
  btn.onmouseenter = () => { btn.style.filter = 'brightness(1.15)'; };
  btn.onmouseleave = () => { btn.style.filter = ''; };
  btn.onclick = () => envoyer();
  document.body.appendChild(btn);
  // l'application MyEasyOptic change d'écran sans recharger la page : on vérifie régulièrement
  setInterval(() => { btn.style.display = by('PV Monture').length ? 'inline-flex' : 'none'; }, 700);

  /* ---------- contexte : magasin, collaborateur connecté, client (statistiques, remise réseau du magasin) ---------- */
  function contexte() {
    const leaves = [...document.querySelectorAll('div, span, td, a, b')].filter(e => e.offsetParent && e.childElementCount === 0 && e.textContent.trim());
    const ctx = { magasin: '', codeClient: '', technicien: '', client: '' };
    // en-tête : « Benjamin CHARRASSIER - Code client : 7443 »
    const who = leaves.find(e => /-\s*Code client\s*:\s*\d+/i.test(e.textContent));
    if (who) {
      const m = /^(.*?)\s*-\s*Code client\s*:\s*(\d+)/i.exec(who.textContent.trim());
      if (m) { ctx.technicien = m[1].trim(); ctx.codeClient = m[2]; }
    }
    // nom du magasin sous le logo « MyEasyOptic »
    const logo = leaves.find(e => e.textContent.trim() === 'MyEasyOptic' && e.getBoundingClientRect().top < 80);
    if (logo) {
      const r = logo.getBoundingClientRect();
      const sub = leaves.find(e => { const q = e.getBoundingClientRect(); return e !== logo && q.top > r.top && q.top - r.bottom < 25 && Math.abs(q.left - r.left) < 60 && /^[A-ZÀ-Ü0-9 '’\-.]{3,}$/.test(e.textContent.trim()); });
      if (sub) ctx.magasin = sub.textContent.trim();
    }
    // client : titre de la fiche équipement « Éq. n°… – NOM Prénom – jj/mm/aaaa », sinon onglet ouvert, sinon champs Nom / Prénom
    const eq = leaves.map(e => /Éq\.\s*n°\s*\d+\s*[–-]\s*(.+?)\s*[–-]\s*\d{2}\/\d{2}\/\d{4}/.exec(e.textContent)).find(Boolean);
    if (eq) ctx.client = eq[1].trim();
    if (!ctx.client) {
      const tab = leaves.filter(e => { const q = e.getBoundingClientRect(); return q.top > 45 && q.top < 90 && !/^(Menu|\+|Sélection Verre|Accueil)$/i.test(e.textContent.trim()) && e.textContent.trim().length > 2; })
        .find(e => /[a-zà-ü]/i.test(e.textContent) && !/MyEasyOptic|Code client/i.test(e.textContent));
      if (tab) ctx.client = tab.textContent.trim();
    }
    if (!ctx.client) {
      const v = p => (vis().find(i => i.placeholder === p)?.value || '').trim();
      ctx.client = [v('Nom'), v('Prénom')].filter(Boolean).join(' ');
    }
    return ctx;
  }

  /* ---------- aller : devis -> Podium ---------- */
  let current = null, win = null;
  function envoyer() {
    const price = by('PV Monture')[0];
    if (!price) return note("Podium : ouvrez d'abord l'écran de vente / devis du client.", false);
    const S = by('Sph.'), C = by('Cyl.'), A = by('Axe'), D = by('Add.'), PR = by('Prisme'), BA = by('Base');
    const val = (arr, k) => ((arr[k] && arr[k].value) || '').trim();
    const eye = k => ({ sph: val(S, k), cyl: val(C, k), axe: val(A, k), add: val(D, k) });
    const filled = e => Object.values(e).some(Boolean);
    // les deux premières lignes Sph. sont l'ordonnance, les deux suivantes les lignes verres
    const pick = (o, v) => (S.length >= 4 && !filled(eye(o)) ? eye(v) : eye(o));
    const rx = { od: pick(0, 2), og: pick(1, 3) };
    rx.od.prism = val(PR, 0); rx.od.base = val(BA, 0); rx.og.prism = val(PR, 1); rx.og.base = val(BA, 1);
    current = { type: 'podium-client', id: Date.now(), rx, framePrice: price.value, ctx: contexte() };
    console.log('[Podium] contexte MyEasyOptic :', current.ctx);
    win = window.open(PODIUM, 'podium-l4c84l');
    if (!win) return note('Podium : autorisez les fenêtres pop-up pour MyEasyOptic.', false);
    const id = current.id; let n = 0;
    const t = setInterval(() => {   // renvoie jusqu'à ce que Podium soit prêt (connexion comprise), 2 minutes max
      if (!current || current.id !== id || current.ack || ++n > 240 || win.closed) return clearInterval(t);
      win.postMessage(current, ORIGIN);
    }, 500);
    note('Podium ouvert avec la correction et la monture de ce devis.', true);
  }

  /* ---------- retour : Podium -> devis ---------- */
  window.addEventListener('message', e => {
    if (e.origin !== ORIGIN || !e.data) return;
    if (e.data.type === 'podium-ack' && current && e.data.id === current.id) current.ack = true;
    if (e.data.type === 'podium-verres') coller(e.data);
  });

  // boutons MyEasyOptic (GWT) : ils réagissent à l'appui souris (mousedown / mouseup), pas au simple clic
  const press = el => {
    const r = el.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: window, clientX: r.left + 5, clientY: r.top + 5, button: 0 };
    ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(t => el.dispatchEvent(new MouseEvent(t, o)));
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // attend qu'une condition soit vraie (renvoie sa valeur), ou null après le délai
  const waitFor = async (fn, ms = 8000, step = 250) => {
    for (let t = 0; t <= ms; t += step) { const v = fn(); if (v) return v; await sleep(step); }
    return null;
  };
  const leaf = (root, txt) => [...root.querySelectorAll('div, td, span')].find(e => e.offsetParent && e.childElementCount === 0 && e.textContent.trim() === txt);
  const setVal = (el, v) => {
    el.focus(); el.value = v;
    ['input', 'keyup', 'change'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
    el.blur();
  };
  // fenêtre MyEasyOptic (popup) contenant un texte donné
  const PAT = 300000; // attente de l'opticien : 5 minutes
  // étape : attend la condition ; si elle tarde, demande l'action à l'opticien puis reprend dès qu'elle est faite
  const etape = async (fn, ms, msg) => {
    const v = await waitFor(fn, ms);
    if (v || !msg) return v;
    note(msg, true, PAT);
    return await waitFor(fn, PAT, 400);
  };
  // clic robuste : appui souris GWT, puis clic natif si rien n'a bougé
  const cliquer = async (el, done, ms = 1500) => {
    press(el);
    if (await waitFor(done, ms, 150)) return true;
    el.click();
    return !!(await waitFor(done, ms, 150));
  };
  const leafIn = (root, re) => [...root.querySelectorAll('*')].filter(x => x.offsetParent && x.childElementCount === 0 && re.test(x.textContent.trim()));

  // pendant un envoi Podium : confirme d'office le retrait des anciens suppléments (« oui »)
  let running = 0;
  setInterval(() => {
    if (Date.now() > running) return;
    const pop = [...document.querySelectorAll('div')]
      .filter(x => x.offsetParent && /vont être retirés/.test(x.textContent) && /Confirmez-vous/.test(x.textContent) && leafIn(x, /^oui$/i).length)
      .sort((a, b) => a.textContent.length - b.textContent.length)[0];
    if (!pop || Date.now() - (pop._podium || 0) < 1500) return;
    pop._podium = Date.now();
    const oui = leafIn(pop, /^oui$/i)[0];
    press(oui.closest('[role=button], a, button') || oui);
    console.log('[Podium] retrait des anciens suppléments confirmé');
  }, 300);

  const popup = txt => [...document.querySelectorAll('div')].filter(x => x.offsetParent && x.textContent.includes(txt) && x.querySelector('input'))
    .sort((a, b) => a.textContent.length - b.textContent.length)[0];

  async function coller(d) {
    running = Date.now() + 15 * 60000;
    try { await collerVerres(d); } finally { running = Date.now() + 5000; }
  }

  async function collerVerres(d) {
    const od = by('Libellé Verre Œil Droit')[0], og = by('Libellé Verre Œil Gauche')[0];
    if (!od || !og) return note("Podium : revenez sur l'écran du devis pour recevoir les verres.", false);
    setVal(od, d.od); setVal(og, d.og);
    window.focus();
    od.scrollIntoView({ block: 'center' });
    await sleep(250);

    // 1. loupe du verre OD -> Sélection Verre
    const r = od.getBoundingClientRect();
    const img = document.elementFromPoint(r.left - 14, r.top + r.height / 2);
    const loupe = img && img.closest('[role=button]');
    if (loupe) press(loupe);
    const search = await etape(() => vis().find(i => /Libellé \(contient/.test(i.placeholder)), 8000,
      'Cliquez sur la loupe du verre : la suite se fera automatiquement.');
    if (!search) return;

    // 2. même verre pour les deux yeux : recherche exacte par code EDI (« Recherche avancée »)
    const sameLens = d.od === d.og;
    if (sameLens && d.odCode) {
      const adv = [...document.querySelectorAll('[title="Recherche avancée"]')].find(a => a.offsetParent);
      if (adv) {
        press(adv);
        const dlg = await waitFor(() => popup('Filtre sur la liste de recherche de verre'));
        if (dlg) {
          await sleep(500); // MyEasyOptic finit d'initialiser la fenêtre
          const inputs = [...dlg.querySelectorAll('input')].filter(i => i.offsetParent && i.type !== 'checkbox');
          // nom d'un champ : texte indicatif, titre, aria-label ou étiquette <label for>
          const nameOf = i => [i.placeholder, i.title, i.getAttribute('aria-label'), i.id && dlg.querySelector(`label[for="${i.id}"]`)?.textContent].filter(Boolean).join(' ').trim();
          // sinon : champ placé sur la même ligne que le libellé affiché à gauche
          const byRow = txt => {
            const l = [...dlg.querySelectorAll('*')].find(e => e.offsetParent && e.childElementCount === 0 && e.textContent.trim() === txt);
            if (!l) return null;
            const y = l.getBoundingClientRect().top + l.getBoundingClientRect().height / 2;
            return inputs.filter(i => { const r = i.getBoundingClientRect(); return y >= r.top - 4 && y <= r.bottom + 4; })
              .sort((a, b) => a.getBoundingClientRect().left - b.getBoundingClientRect().left)[0] || null;
          };
          const field = txt => inputs.find(i => nameOf(i) === txt) || byRow(txt);
          const lib = field('Libellé du verre'), edi = field('Code EDI');
          console.log('[Podium] recherche avancée :', { libellé: !!lib, codeEDI: !!edi, code: d.odCode });
          if (lib && edi && lib !== edi) {
            setVal(lib, ''); setVal(edi, d.odCode);
            if (edi.value !== d.odCode) { edi.focus(); edi.value = d.odCode; edi.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' })); }
            const ok = [...dlg.querySelectorAll('[role=button]')].find(b => b.offsetParent && (b.title === 'Valider' || b.textContent.trim().toLowerCase() === 'ok'));
            if (ok) press(ok);
            const closed = await waitFor(() => !dlg.offsetParent, 2500);
            if (!closed) note('Code EDI ' + d.odCode + ' saisi : cliquez sur « ok » de la recherche avancée.', true);
          } else {
            note('Recherche avancée : saisissez le code EDI ' + d.odCode + ' puis « ok ».', true);
          }
          await sleep(1200);
        }
      }
    }

    // 3. ligne exacte
    if (!sameLens) return note('OD et OG sont différents : sélectionnez chaque œil, choisissez le diamètre puis OK.', true);
    const cell = await etape(() => { const c = leaf(document, d.od); return c && c.getBoundingClientRect().top > 180 ? c : null; }, 20000,
      'Recherchez le verre « ' + d.od + ' » : la suite se fera automatiquement.');
    if (!cell) return;
    press(cell);
    const row = cell.closest('tr');

    // 4. diamètre : 65/70, sinon le plus proche (formats « 65/70 » ou « 70 »)
    // la liste n'est pas forcément dans la même ligne de tableau que le libellé : on la repère par sa position
    // MyEasyOptic redessine le tableau après la sélection : on retrouve la cellule à chaque fois
    const top0 = search.getBoundingClientRect().bottom;
    const cellNow = () => {
      const c = cell.isConnected && cell.offsetParent ? cell : leaf(document, d.od);
      return c && c.getBoundingClientRect().top > top0 ? c : null;
    };
    const selects = () => [...document.querySelectorAll('select')].filter(x => x.offsetParent && x.getBoundingClientRect().top > top0);
    const findSel = () => {
      const all = selects(), c = cellNow();
      if (c) {
        const y = c.getBoundingClientRect().top + c.getBoundingClientRect().height / 2;
        const s = all.find(x => { const r = x.getBoundingClientRect(); return y >= r.top - 8 && y <= r.bottom + 8; });
        if (s) return s;
        // sinon : liste contenue dans la même ligne (premier ancêtre qui en contient une)
        for (let p = c.parentElement, k = 0; p && k < 8; p = p.parentElement, k++) {
          const s2 = [...p.querySelectorAll('select')].find(x => x.offsetParent);
          if (s2) return p.getBoundingClientRect().height < 80 ? s2 : null;
        }
      }
      // une seule ligne de résultat (recherche par code EDI) : la seule liste visible sous la recherche
      return all.length === 1 ? all[0] : null;
    };
    // MyEasyOptic ne remplit la liste qu'au clic : on simule l'ouverture jusqu'à voir les diamètres
    const fill = async x => {
      for (let k = 0; k < 12 && x && [...x.options].filter(o => /\d/.test(o.text)).length === 0; k++) {
        const r = x.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: window, clientX: r.left + 5, clientY: r.top + 5, button: 0 };
        x.focus();
        ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(t => x.dispatchEvent(new MouseEvent(t, o)));
        x.dispatchEvent(new Event('focus'));
        await sleep(400);
        x = findSel() || x;
      }
      return x;
    };
    const diamOk = x => !!(x && x.selectedIndex >= 0 && /\d/.test(x.options[x.selectedIndex].text));
    let sel = await waitFor(findSel, 5000);
    if (!sel) console.log('[Podium] diagnostic diamètre :', {
      cellule: !!cellNow(), celluleY: cellNow() && Math.round(cellNow().getBoundingClientRect().top),
      listes: [...document.querySelectorAll('select')].map(x => ({ y: Math.round(x.getBoundingClientRect().top), visible: !!x.offsetParent, options: x.options.length })),
      autres: [...document.querySelectorAll('[role=listbox], [role=combobox], [aria-haspopup]')].filter(x => x.offsetParent).map(x => x.tagName + '.' + x.className).slice(0, 8) });
    if (sel) sel = await fill(sel);
    console.log('[Podium] liste des diamètres trouvée :', !!sel, sel && [...sel.options].map(o => o.text));
    if (sel && !diamOk(sel)) {
      const score = t => { const n = (t.match(/\d+/g) || []).map(Number); if (!n.length) return 1e9;
        return n.length >= 2 ? Math.abs(n[0] - 65) + Math.abs(n[1] - 70) : Math.abs(n[0] - 70); };
      const idx = [...sel.options].map((o, i) => ({ o, i })).filter(x => x.o.text.trim() && /\d/.test(x.o.text))
        .sort((x, y) => score(x.o.text) - score(y.o.text) || parseInt(y.o.text) - parseInt(x.o.text))[0];
      if (idx) {
        sel.focus();
        sel.selectedIndex = idx.i;
        ['input', 'change'].forEach(t => sel.dispatchEvent(new Event(t, { bubbles: true })));
        sel.blur();
      }
      console.log('[Podium] diamètre choisi :', idx && idx.o.text);
      await sleep(900);
      sel = findSel() || sel; // MyEasyOptic peut redessiner la ligne
    }
    // si le diamètre n'est toujours pas pris en compte : on laisse l'opticien le choisir, puis on reprend la suite
    if (!diamOk(sel)) {
      note('Choisissez le diamètre : la suite (suppléments, validation) se fera automatiquement.', true, PAT);
      sel = await waitFor(() => { const x = findSel(); return diamOk(x) ? x : null; }, 300000, 400);
      if (!sel) return;
      await sleep(700);
    }
    const diam = sel.options[sel.selectedIndex].text.trim();

    // 5. suppléments (Précal, couleur Transitions, prisme) puis validation
    // bouton « ok » d'une fenêtre : d'abord l'élément « Valider », sinon le texte « ok » le plus bas
    const okBtn = root => {
      const v = [...root.querySelectorAll('[title="Valider"]')].find(x => x.offsetParent);
      if (v) return v;
      const t = leafIn(root, /^ok$/i).sort((a, b) => b.getBoundingClientRect().top - a.getBoundingClientRect().top)[0];
      return t && (t.closest('[role=button], a, button') || t);
    };
    const ouvert = el => !!(el && el.isConnected && el.offsetParent);
    const supps = d.supps || [];
    const done = [];
    const fin = () => note(`Verre Ø ${diam}` + (done.length ? ' + ' + done.join(' + ') : '') + ' : vérifiez le devis.', true);
    // fiche de l'équipement (Précalibrage…) ouverte après la validation : on la ferme par « ok » pour revenir au devis
    const fermerFiche = async () => {
      const fiche = await waitFor(() => [...document.querySelectorAll('div')]
        .filter(x => x.offsetParent && x.textContent.includes('Boxing A') && x.textContent.includes('Éq. n') && okBtn(x))
        .sort((p, q) => p.textContent.length - q.textContent.length)[0], 6000);
      if (!fiche) return fin();
      await sleep(500);
      const ok = okBtn(fiche);
      const closed = ok && await cliquer(ok, () => !ouvert(fiche));
      console.log('[Podium] fiche équipement fermée :', !!closed, ok);
      if (!closed) {
        note('Cliquez sur « ok » de la fiche équipement pour revenir au devis.', true, PAT);
        if (!await waitFor(() => !ouvert(fiche), PAT, 400)) return;
      }
      fin();
    };

    const norm = t => (t || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
    if (!supps.length) {
      const valider = [...document.querySelectorAll('[role=button]')].find(x => x.offsetParent && /^Valider le choix des verres/i.test(x.title));
      if (valider) press(valider);
      else note('Cliquez sur OK pour valider le verre : la suite se fera automatiquement.', true, PAT);
      return fermerFiche();
    }
    const findDlg = () => [...document.querySelectorAll('div')]
      .filter(x => x.offsetParent && x.textContent.includes('réinitialiser les critères') && x.textContent.includes('Total verre et suppl') && x.querySelector('input[type=checkbox]'))
      .sort((p, q) => p.textContent.length - q.textContent.length)[0];
    const plus = [...document.querySelectorAll('[role=button]')].find(x => x.offsetParent && (/^Suppl/i.test(x.title) || /^Suppl/i.test(x.getAttribute('aria-label') || '') || /^Suppl\.?$/i.test(x.textContent.trim())));
    console.log('[Podium] bouton suppléments :', !!plus);
    if (plus) press(plus);
    const dlg = await etape(findDlg, 8000, 'Cliquez sur « + » (suppléments) : la suite se fera automatiquement.');
    if (!dlg) return;
    await sleep(500);
    const missing = [];
    for (const sup of supps) {
      const first = [...dlg.querySelectorAll('[title="Première page"]')].find(x => x.offsetParent);
      if (first) { press(first); await sleep(600); }
      let tr = null;
      for (let page = 0; page < 12 && !tr; page++) {
        // ligne repérée par son code ou par son libellé MyEasyOptic
        tr = [...dlg.querySelectorAll('tr')].find(t => t.offsetParent && t.querySelector('input[type=checkbox]') &&
          [...t.querySelectorAll('td, div')].some(c => c.childElementCount === 0 && (c.textContent.trim() === sup.code || (sup.lib && norm(c.textContent) === norm(sup.lib)))));
        if (tr) break;
        const next = [...dlg.querySelectorAll('[title="Page suivante"]')].find(x => x.offsetParent);
        if (!next) break;
        press(next); await sleep(700);
      }
      if (!tr) { missing.push(sup.name); continue; }
      const boxes = [...tr.querySelectorAll('input[type=checkbox]')]; // [OD, OG]
      (sup.eyes || ['od', 'og']).forEach(e => { const cb = boxes[e === 'og' ? 1 : 0]; if (cb && !cb.checked && !cb.disabled) cb.click(); });
      done.push(sup.name);
      await sleep(400);
    }
    console.log('[Podium] suppléments cochés :', done, 'introuvables :', missing);
    if (missing.length) {
      note('Ø ' + diam + ' · ' + (done.length ? done.join(' + ') + ' coché(s). ' : '') + 'Introuvable(s) : ' + missing.join(', ') + ' — cochez-le(s) puis « ok » : la suite se fera automatiquement.', false, PAT);
    } else {
      const ok = okBtn(dlg);
      console.log('[Podium] ok des suppléments :', !!ok);
      if (ok && !await cliquer(ok, () => !ouvert(findDlg()), 2000)) {
        // supplément obligatoire manquant (ex. couleur Transitions) : MyEasyOptic affiche une alerte
        const alerte = [...document.querySelectorAll('div')].find(x => x.offsetParent && /Information importante/.test(x.textContent) && /suppléments obligatoires/.test(x.textContent));
        note(alerte ? 'MyEasyOptic demande un supplément obligatoire (couleur Transitions ?) : choisissez-le puis « ok », la suite se fera automatiquement.'
          : 'Cliquez sur « ok » des suppléments : la suite se fera automatiquement.', false, PAT);
      }
    }
    // on reprend dès que la fenêtre des suppléments est fermée (par le script ou par l'opticien)
    if (!await waitFor(() => !ouvert(findDlg()), PAT, 400)) return;
    await fermerFiche();
  }
})();
