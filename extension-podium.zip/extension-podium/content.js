/* Podium L4C84L pour MyEasyOptic — script de l'extension, exécuté dans les pages MyEasyOptic.
   - Affiche un bouton « → Podium » tant qu'un devis (écran de vente) est ouvert.
   - Au clic : lit la correction (bloc Ordonnance, à défaut lignes verres) et le prix monture, ouvre Podium
     et lui transmet ces données (postMessage, directement d'onglet à onglet, sans serveur).
   - Au retour de Podium : colle le libellé des verres OD / OG, ouvre la loupe, recherche le verre par son code EDI,
     présélectionne la ligne ; dès que l'opticien a choisi le diamètre, ouvre le catalogue des suppléments et coche
     ceux choisis dans Podium (Précal, couleur Transitions). L'opticien vérifie et valide lui-même (« ok »). */
(() => {
  const PODIUM = 'https://lachal-groupe.github.io/Podium/';
  const ORIGIN = 'https://lachal-groupe.github.io';
  const vis = () => [...document.querySelectorAll('input')].filter(i => i.offsetParent !== null);
  const by = p => vis().filter(i => i.placeholder === p);

  /* ---------- messages à l'écran ---------- */
  const note = (msg, ok) => {
    let d = document.getElementById('podium-note');
    if (!d) {
      d = document.createElement('div'); d.id = 'podium-note';
      d.style.cssText = 'position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483647;padding:12px 22px;border-radius:12px;font:600 14px/1.4 Segoe UI,Arial,sans-serif;color:#fff;box-shadow:0 8px 28px rgba(0,0,0,.28);max-width:82vw;text-align:center';
      document.body.appendChild(d);
    }
    d.style.background = ok ? '#1d4fd7' : '#c13246'; d.textContent = msg;
    clearTimeout(d._t); d._t = setTimeout(() => d.remove(), 10000);
  };

  /* ---------- bouton « → Podium » (visible seulement sur un devis) ---------- */
  const btn = document.createElement('button');
  btn.id = 'podium-btn'; btn.type = 'button'; btn.title = 'Ouvrir Podium avec la correction et la monture de ce devis';
  btn.innerHTML = '<span style="display:inline-flex;align-items:flex-end;gap:2px;height:16px;margin-right:8px">'
    + '<i style="width:5px;height:60%;background:#fff;opacity:.75;border-radius:2px"></i><i style="width:5px;height:100%;background:#fff;border-radius:2px"></i><i style="width:5px;height:40%;background:#fff;opacity:.55;border-radius:2px"></i></span>Podium';
  btn.style.cssText = 'position:fixed;right:18px;top:50%;transform:translateY(-50%);z-index:2147483646;display:none;align-items:center;padding:12px 18px;border:0;border-radius:999px;background:linear-gradient(100deg,#0b2a7a,#1d4fd7);color:#fff;font:800 15px Segoe UI,Arial,sans-serif;box-shadow:0 8px 24px rgba(11,42,122,.35);cursor:pointer';
  btn.onmouseenter = () => { btn.style.filter = 'brightness(1.15)'; };
  btn.onmouseleave = () => { btn.style.filter = ''; };
  btn.onclick = () => envoyer();
  document.body.appendChild(btn);
  // l'application MyEasyOptic change d'écran sans recharger la page : on vérifie régulièrement
  setInterval(() => { btn.style.display = by('PV Monture').length ? 'inline-flex' : 'none'; }, 700);

  /* ---------- aller : devis -> Podium ---------- */
  let current = null, win = null;
  function envoyer() {
    const price = by('PV Monture')[0];
    if (!price) return note("Podium : ouvrez d'abord l'écran de vente / devis du client.", false);
    const S = by('Sph.'), C = by('Cyl.'), A = by('Axe'), D = by('Add.');
    const val = (arr, k) => ((arr[k] && arr[k].value) || '').trim();
    const eye = k => ({ sph: val(S, k), cyl: val(C, k), axe: val(A, k), add: val(D, k) });
    const filled = e => Object.values(e).some(Boolean);
    // les deux premières lignes Sph. sont l'ordonnance, les deux suivantes les lignes verres
    const pick = (o, v) => (S.length >= 4 && !filled(eye(o)) ? eye(v) : eye(o));
    current = { type: 'podium-client', id: Date.now(), rx: { od: pick(0, 2), og: pick(1, 3) }, framePrice: price.value };
    win = window.open(PODIUM, 'podium-l4c84l');
    if (!win) return note('Podium : autorisez les fenêtres pop-up pour MyEasyOptic.', false);
    const id = current.id; let n = 0;
    const t = setInterval(() => {   // renvoie jusqu'à ce que Podium soit prêt (connexion comprise), 2 minutes max
      if (!current || current.id !== id || current.ack || ++n > 240 || win.closed) return clearInterval(t);
      win.postMessage(current, ORIGIN);
    }, 500);
    note('Podium ouvert avec la correction et la monture de ce devis.', true);
  }

  /* ---------- retour : Podium -> devis ---------- */
  window.addEventListener('message', e => {
    if (e.origin !== ORIGIN || !e.data) return;
    if (e.data.type === 'podium-ack' && current && e.data.id === current.id) current.ack = true;
    if (e.data.type === 'podium-verres') coller(e.data);
  });

  // boutons MyEasyOptic (GWT) : ils réagissent à l'appui souris (mousedown / mouseup), pas au simple clic
  const press = el => {
    const r = el.getBoundingClientRect(), o = { bubbles: true, cancelable: true, view: window, clientX: r.left + 5, clientY: r.top + 5, button: 0 };
    ['mouseover', 'mousedown', 'mouseup', 'click'].forEach(t => el.dispatchEvent(new MouseEvent(t, o)));
  };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  // attend qu'une condition soit vraie (renvoie sa valeur), ou null après le délai
  const waitFor = async (fn, ms = 8000, step = 250) => {
    for (let t = 0; t <= ms; t += step) { const v = fn(); if (v) return v; await sleep(step); }
    return null;
  };
  const leaf = (root, txt) => [...root.querySelectorAll('div, td, span')].find(e => e.offsetParent && e.childElementCount === 0 && e.textContent.trim() === txt);
  const setVal = (el, v) => {
    el.focus(); el.value = v;
    ['input', 'keyup', 'change'].forEach(t => el.dispatchEvent(new Event(t, { bubbles: true })));
    el.blur();
  };
  // fenêtre MyEasyOptic (popup) contenant un texte donné
  const popup = txt => [...document.querySelectorAll('div')].filter(x => x.offsetParent && x.textContent.includes(txt) && x.querySelector('input'))
    .sort((a, b) => a.textContent.length - b.textContent.length)[0];

  async function coller(d) {
    const od = by('Libellé Verre Œil Droit')[0], og = by('Libellé Verre Œil Gauche')[0];
    if (!od || !og) return note("Podium : revenez sur l'écran du devis pour recevoir les verres.", false);
    setVal(od, d.od); setVal(og, d.og);
    window.focus();
    od.scrollIntoView({ block: 'center' });
    await sleep(250);

    // 1. loupe du verre OD -> Sélection Verre
    const r = od.getBoundingClientRect();
    const img = document.elementFromPoint(r.left - 14, r.top + r.height / 2);
    const loupe = img && img.closest('[role=button]');
    if (!loupe) return note('Verres Podium collés : cliquez sur la loupe pour les sélectionner.', true);
    press(loupe);
    const search = await waitFor(() => vis().find(i => /Libellé \(contient/.test(i.placeholder)));
    if (!search) return note('Verres Podium collés : cliquez sur la loupe pour les sélectionner.', true);

    // 2. même verre pour les deux yeux : recherche exacte par code EDI (« Recherche avancée »)
    const sameLens = d.od === d.og;
    if (sameLens && d.odCode) {
      const adv = [...document.querySelectorAll('[title="Recherche avancée"]')].find(a => a.offsetParent);
      if (adv) {
        press(adv);
        const dlg = await waitFor(() => popup('Filtre sur la liste de recherche de verre'));
        if (dlg) {
          // champ placé sur la même ligne que son libellé
          const field = txt => { const l = leaf(dlg, txt); if (!l) return null; const y = l.getBoundingClientRect().top;
            return [...dlg.querySelectorAll('input')].find(i => i.offsetParent && i.type !== 'checkbox' && Math.abs(i.getBoundingClientRect().top - y) < 12); };
          const lib = field('Libellé du verre'), edi = field('Code EDI');
          if (lib && edi) {
            setVal(lib, ''); setVal(edi, d.odCode);
            const ok = [...dlg.querySelectorAll('[role=button]')].find(b => b.title === 'Valider' || b.textContent.trim() === 'ok');
            if (ok) press(ok);
            await sleep(1200);
          }
        }
      }
    }

    // 3. présélection de la ligne exacte
    const cell = await waitFor(() => { const c = leaf(document, d.od); return c && c.getBoundingClientRect().top > 180 ? c : null; }, 6000);
    if (cell) press(cell);
    const precalTxt = (d.supps || []).length ? ' Puis les suppléments (' + d.supps.map(x => x.name).join(', ') + ') seront cochés automatiquement.' : '';
    if (!sameLens) return note('OD et OG sont différents : sélectionnez chaque œil, choisissez le diamètre puis OK.', true);
    note((cell ? 'Verre présélectionné : choisissez le diamètre.' : 'Cliquez sur la ligne exacte, choisissez le diamètre.') + (precalTxt || ' Puis OK.'), true);
    if (!cell || !(d.supps || []).length) return;

    // 4. diamètre choisi par l'opticien -> catalogue des suppléments, cases cochées (OK laissé à l'opticien)
    const row = cell.closest('tr');
    const chosen = await waitFor(() => { const s = row && row.querySelector('select'); return s && s.value ? s : null; }, 300000, 400);
    if (!chosen) return;
    await sleep(600);
    const plus = [...document.querySelectorAll('[role=button]')].find(b => b.offsetParent && b.title === 'Suppléments');
    if (!plus) return note('Cliquez sur « + » pour ajouter : ' + d.supps.map(x => x.name).join(', ') + '.', true);
    press(plus);
    const dlg = await waitFor(() => popup('réinitialiser les critères'));
    if (!dlg) return note('Cliquez sur « + » pour ajouter : ' + d.supps.map(x => x.name).join(', ') + '.', true);
    const done = [], missing = [];
    for (const sup of d.supps) {
      const first = [...dlg.querySelectorAll('[title="Première page"]')].find(a => a.offsetParent);
      if (first) { press(first); await sleep(500); }
      let found = null;
      for (let page = 0; page < 10 && !found; page++) {
        found = leaf(dlg, sup.code);
        if (found) break;
        const next = [...dlg.querySelectorAll('[title="Page suivante"]')].find(a => a.offsetParent);
        if (!next) break;
        press(next); await sleep(600);
      }
      if (!found) { missing.push(sup.name); continue; }
      found.closest('tr').querySelectorAll('input[type=checkbox]').forEach(cb => { if (!cb.checked && !cb.disabled) cb.click(); });
      done.push(sup.name);
      await sleep(300);
    }
    note((done.length ? done.join(' + ') + ' coché(s) : vérifiez puis « ok ».' : '') + (missing.length ? ' Introuvable(s) : ' + missing.join(', ') + ' — à cocher à la main.' : ''), !missing.length);
  }
})();
